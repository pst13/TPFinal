﻿namespace MazeDisplay
{
    public enum Direction
    {
        Invalid,
        North,
        East,
        South,
        West,
    }
}
